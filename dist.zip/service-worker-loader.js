import './assets/index.js-43zJY8PU.js';
